				<div id="subpage_sidebar" class="sidebar fourcol last clearfix" role="complementary">

					<?php if ( is_active_sidebar( 'subpage_sidebar' ) ) : ?>

						<?php dynamic_sidebar( 'subpage_sidebar' ); ?>

					<?php else : ?>

					<?php endif; ?>

				</div>
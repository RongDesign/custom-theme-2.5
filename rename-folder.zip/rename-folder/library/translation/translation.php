<?php
/* Welcome to WebDrafter.com :)
Thanks to the fantastic work by WebDrafter.com users, we've now
the ability to translate WebDrafter.com into different languages.

Produced by: WebDrafter.com @webdrafter
URL: http://www.webdrafter.com/

Developed by: Dave Moore @rongdesigncom
URL: http://www.rongdesign.com/

Base on Bones Theme by: Eddie Machado
URL: http://themble.com/

*/



// Adding Translation Option
load_theme_textdomain( 'webdraftertheme', get_template_directory() .'/library/translation' );
?>

				<div id="contact_sidebar" class="sidebar fourcol last clearfix" role="complementary">

					<?php if ( is_active_sidebar( 'contact_sidebar' ) ) : ?>

						<?php dynamic_sidebar( 'contact_sidebar' ); ?>

					<?php else : ?>

					<?php endif; ?>

				</div>